package com.example.flickrbrowserapp_laila

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.URL

class ViewActivity : AppCompatActivity() {

    lateinit var Recycler_View: RecyclerView
    lateinit var Constraint_Layout: ConstraintLayout
    lateinit var image: ImageView

    var Details_List = arrayListOf<Details>()
    var Value = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)

        Constraint_Layout = findViewById(R.id.Constraint_Layout)
        image = findViewById(R.id.image)

        Recycler_View = findViewById(R.id.Recycler_View)
        Recycler_View.adapter = Adapter(this, Details_List)
        Recycler_View.layoutManager = LinearLayoutManager(this)

        val intent = intent
        Value = intent.getStringExtra("search Value").toString().replace(" ", "&")
        requestApi()
    }

    fun show(photo: String) {
        Glide.with(this)
            .load("$photo")
            .into(image)
    }

    private fun requestApi() {

        CoroutineScope(Dispatchers.IO).launch {

            val data = async {
                fetchData()
            }.await()

            if (data.isNotEmpty()) {
                updateData(data)
            }
        }
    }

    private suspend fun updateData(data: String) {

        withContext(Dispatchers.Main)
        {

            val JSON_Object = JSONObject(data)
            val photos = JSON_Object.getJSONObject("photos")
            val photo_Array = photos.getJSONArray("photo")

            for (i in 0 until photo_Array.length()) {

                var photo_Title = photo_Array.getJSONObject(i).getString("title")
                var img = photo_Array.getJSONObject(i).getString("url_t")
                Details_List.add(Details(img, photo_Title))
                Recycler_View.adapter?.notifyDataSetChanged()
            }
        }
    }

    private fun fetchData(): String {
        var response = ""
        try {
            response = URL("https://www.flickr.com/services/rest/?method=flickr.photos.search&api_key=732fad76524987681acc5e9889c1d636&tags=$Value&format=json&nojsoncallback=1&extras=url_t").readText(Charsets.UTF_8)

        } catch (e: Exception) {
            Toast.makeText(applicationContext, "Error $e".uppercase(), Toast.LENGTH_SHORT).show()
        }
        return response

    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.view_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.Search -> {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}