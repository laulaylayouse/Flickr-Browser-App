package com.example.flickrbrowserapp_laila

import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.item_row.view.*


class Adapter ( val View_Activity: ViewActivity ,private val messages: List<Details>):
    RecyclerView.Adapter<Adapter.ItemViewHolder>(){
    class ItemViewHolder (itemView: View): RecyclerView.ViewHolder(itemView){}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.item_row,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        var message = messages[position]


        holder.itemView.apply {
            Glide.with(this).load("${message.imageView}").into(Image_View)

            TextView_Name.text = message.title
            Image_View.setOnClickListener{

                View_Activity.show("${message.imageView}")


            }

        }
    }

    override fun getItemCount()= messages.size
}

