package com.example.flickrbrowserapp_laila

data class Details (val imageView: String, val title: String)